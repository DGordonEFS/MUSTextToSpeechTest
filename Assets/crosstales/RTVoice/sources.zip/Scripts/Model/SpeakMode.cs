﻿namespace Crosstales.RTVoice.Model
{
    /// <summary>Available Speak-modes.</summary>
    public enum SpeakMode
    {
        Speak,
        SpeakNative
    }
}
// Copyright 2016 www.crosstales.com